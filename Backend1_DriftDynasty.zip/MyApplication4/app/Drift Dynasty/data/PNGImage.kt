package com.driftdynasty.data

import com.google.gson.annotations.SerializedName

data class PNGImage(
    @SerializedName("id")
    val id: Int,

    @SerializedName("name")
    val name: String,

    @SerializedName("rarity")
    val rarity: String, // "common", "rare", "epic", "legendary"

    @SerializedName("image_url")
    val imageUrl: String,

    @SerializedName("count")
    val count: Int = 1, // How many of this car the user has

    @SerializedName("description")
    val description: String? = null,

    @SerializedName("car_model")
    val carModel: String? = null,

    @SerializedName("manufacturer")
    val manufacturer: String? = null,

    @SerializedName("year")
    val year: Int? = null,

    @SerializedName("rarity_color")
    val rarityColor: String? = null // Hex color for rarity
) {
    // Helper function to get rarity as enum
    fun getRarityEnum(): CarRarity {
        return when (rarity.lowercase()) {
            "common" -> CarRarity.COMMON
            "rare" -> CarRarity.RARE
            "epic" -> CarRarity.EPIC
            "legendary" -> CarRarity.LEGENDARY
            else -> CarRarity.COMMON
        }
    }
}

enum class CarRarity(val displayName: String, val color: String) {
    COMMON("Common", "#808080"),
    RARE("Rare", "#0070f3"),
    EPIC("Epic", "#8b5cf6"),
    LEGENDARY("Legendary", "#f59e0b")
}