package com.driftdynasty.data

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("id")
    val id: Int,

    @SerializedName("username")
    val username: String,

    @SerializedName("email")
    val email: String? = null,

    @SerializedName("created_at")
    val createdAt: String? = null,

    @SerializedName("total_pulls")
    val totalPulls: Int = 0,

    @SerializedName("total_cars")
    val totalCars: Int = 0,

    @SerializedName("rare_cars")
    val rareCars: Int = 0,

    @SerializedName("epic_cars")
    val epicCars: Int = 0,

    @SerializedName("legendary_cars")
    val legendaryCars: Int = 0,

    @SerializedName("last_pull_time")
    val lastPullTime: String? = null
)
